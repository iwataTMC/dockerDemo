from django.apps import AppConfig


class GpsConfig(AppConfig):
    name = 'gps'
